/**
 * @file LIVMapper.h
 * @brief LiDAR-Inertial-Visual Mapper module for Omni-LIVO
 *
 * @copyright Copyright (c) 2026 Hangzhou Institute for Advanced Study,
 *            University of Chinese Academy of Sciences
 *
 * @par Project: Omni-LIVO
 * Omni-LIVO: Robust RGB-Colored Multi-Camera Visual-Inertial-LiDAR Odometry
 * via Photometric Migration and ESIKF Fusion
 *
 * This work is based on FAST-LIVO2:
 * C. Zheng, W. Xu, Q. Guo, and F. Zhang, "FAST-LIVO2: Fast, direct LiDAR-inertial-visual
 * odometry," IEEE Trans. Robot., vol. 40, pp. 1529-1546, 2024.
 *
 * @author Yinong Cao (cyn_688@163.com), Chenyang Zhang, Xin He*, Yuwei Chen, Chengyu Pu,
 *         Bingtao Wang, Kaile Wu, Shouzheng Zhu, Fei Han, Shijie Liu, Chunlai Li, Jianyu Wang
 * @author *Corresponding author: Xin He (xinhe@ucas.ac.cn)
 *
 * @par Repository
 * https://github.com/elon876/Omni-LIVO
 *
 * @par Citation
 * If you use this code in your research, please cite our paper:
 * Y. Cao et al., "Omni-LIVO: Robust RGB-Colored Multi-Camera Visual-Inertial-LiDAR
 * Odometry via Photometric Migration and ESIKF Fusion," IEEE Robotics and Automation
 * Letters, 2026.
 */

#ifndef LIV_MAPPER_H
#define LIV_MAPPER_H

#include "IMU_Processing.h"
#include "vio.h"
#include "preprocess.h"
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>
#include <nav_msgs/Path.h>
#include <vikit/camera_loader.h>

class LIVMapper {
public:
    LIVMapper(ros::NodeHandle &nh);

    ~LIVMapper();

    void initializeSubscribersAndPublishers(ros::NodeHandle &nh, image_transport::ImageTransport &it);

    void initializeComponents();

    void initializeFiles();

    void run();

    void gravityAlignment();

    void handleFirstFrame();

    void stateEstimationAndMapping();

    void handleVIO();

    void handleLIO();

    void savePCD();

    void processImu();

    bool sync_packages(LidarMeasureGroup &meas);

    void prop_imu_once(StatesGroup &imu_prop_state, const double dt, V3D acc_avr, V3D angvel_avr);

    void imu_prop_callback(const ros::TimerEvent &e);

    void transformLidar(const Eigen::Matrix3d rot, const Eigen::Vector3d t, const PointCloudXYZI::Ptr &input_cloud,
                        PointCloudXYZI::Ptr &trans_cloud);

    void pointBodyToWorld(const PointType &pi, PointType &po);

    void RGBpointBodyToWorld(PointType const *const pi, PointType *const po);

    void standard_pcl_cbk(const sensor_msgs::PointCloud2::ConstPtr &msg);

    void livox_pcl_cbk(const livox_ros_driver2::CustomMsg::ConstPtr &msg_in);

    void imu_cbk(const sensor_msgs::Imu::ConstPtr &msg_in);

    void img_cbk(const sensor_msgs::ImageConstPtr &msg_in, int cam_id);

    void publish_img_rgb(const image_transport::Publisher &pubImage, VIOManagerPtr vio_manager);

    void publish_frame_world(const ros::Publisher &pubLaserCloudFullRes, VIOManagerPtr vio_manager);

    void publish_visual_sub_map(const ros::Publisher &pubSubVisualMap);

    void publish_effect_world(const ros::Publisher &pubLaserCloudEffect, const std::vector<PointToPlane> &ptpl_list);

    void publish_odometry(const ros::Publisher &pubOdomAftMapped);

    void publish_mavros(const ros::Publisher &mavros_pose_publisher);

    void publish_path(const ros::Publisher pubPath);

    void readParameters(ros::NodeHandle &nh);

    template<typename T>
    void set_posestamp(T &out);

    template<typename T>
    void pointBodyToWorld(const Eigen::Matrix<T, 3, 1> &pi, Eigen::Matrix<T, 3, 1> &po);

    template<typename T>
    Eigen::Matrix<T, 3, 1> pointBodyToWorld(const Eigen::Matrix<T, 3, 1> &pi);

    cv::Mat getImageFromMsg(const sensor_msgs::ImageConstPtr &img_msg);

    std::mutex mtx_buffer, mtx_buffer_imu_prop;
    std::condition_variable sig_buffer;

    SLAM_MODE slam_mode_;
    std::unordered_map<VOXEL_LOCATION, VoxelOctoTree *> voxel_map;

    string root_dir;
    string lid_topic, imu_topic, seq_name;
    V3D extT;
    M3D extR;
    std::vector<std::string> camera_img_topics;
    int feats_down_size = 0, max_iterations = 0;

    double res_mean_last = 0.05;
    double gyr_cov = 0, acc_cov = 0, inv_expo_cov = 0;
    double blind_rgb_points = 0.0;
    // double last_timestamp_lidar = -1.0, last_timestamp_imu = -1.0, last_timestamp_img = -1.0;
    double last_timestamp_lidar = -1.0, last_timestamp_imu = -1.0;
    std::vector<double> last_timestamp_imgs;
    double filter_size_surf_min = 0;
    double filter_size_pcd = 0;
    double _first_lidar_time = 0.0;
    double match_time = 0, solve_time = 0, solve_const_H_time = 0;

    bool lidar_map_inited = false, pcd_save_en = false, pub_effect_point_en = false, pose_output_en = false, ros_driver_fix_en = false;
    int pcd_save_interval = -1, pcd_index = 0;
    int pub_scan_num = 1;

    StatesGroup imu_propagate, latest_ekf_state;

    bool new_imu = false, state_update_flg = false, imu_prop_enable = true, ekf_finish_once = false;
    deque<sensor_msgs::Imu> prop_imu_buffer;
    sensor_msgs::Imu newest_imu;
    double latest_ekf_time;
    nav_msgs::Odometry imu_prop_odom;
    ros::Publisher pubImuPropOdom;
    double imu_time_offset = 0.0;

    bool gravity_align_en = false, gravity_align_finished = false;

    bool sync_jump_flag = false;

    bool lidar_pushed = false, imu_en, gravity_est_en, flg_reset = false, ba_bg_est_en = true;
    bool dense_map_en = false;
    int img_en = 1, imu_int_frame = 3;
    bool normal_en = true;
    bool exposure_estimate_en = false;
    double exposure_time_init = 0.0;
    bool inverse_composition_en = false;
    //bool raycast_en = false;
    int lidar_en = 1;
    bool is_first_frame = false;
    int grid_size, patch_size, grid_n_width, grid_n_height, patch_pyrimid_level;
    double outlier_threshold;
    double plot_time;
    int frame_cnt;
    double img_time_offset = 0.0;
    deque<PointCloudXYZI::Ptr> lid_raw_data_buffer;
    deque<double> lid_header_time_buffer;
    deque<sensor_msgs::Imu::ConstPtr> imu_buffer;
    std::vector<deque<cv::Mat>> img_buffers;
    std::vector<deque<double>> img_time_buffers;
    vector<pointWithVar> _pv_list;
    vector<double> extrinT;
    vector<double> extrinR;

    std::vector<std::vector<double>> camera_extrin_Rs;
    std::vector<std::vector<double>> camera_extrin_Ts;
    int num_of_cameras = 0;

    bool vio_dynamic_cov_enabled_;
    int vio_dynamic_cov_warmup_frames = 200;
    double vio_warmup_cov_scale = 500.0;
    int vio_ideal_total_points = 150;
    double vio_max_cov_scale = 2000.0;
    double vio_min_cov_scale = 10.0;
    double vio_dynamic_cov_error_max = 50.0;
    bool raycast_en = false;
    int max_total_points = 300;
    bool enable_cross_camera_tracking = false;

    double IMG_POINT_COV;

    PointCloudXYZI::Ptr visual_sub_map;
    PointCloudXYZI::Ptr feats_undistort;
    PointCloudXYZI::Ptr feats_down_body;
    PointCloudXYZI::Ptr feats_down_world;
    PointCloudXYZI::Ptr pcl_w_wait_pub;
    PointCloudXYZI::Ptr pcl_wait_pub;
    PointCloudXYZRGB::Ptr pcl_wait_save;
    PointCloudXYZRGB::Ptr latest_colored_cloud_;  // Store the latest colored point cloud
    bool save_ply_en = false;
    ofstream fout_pre, fout_out, fout_pcd_pos, fout_points;

    pcl::VoxelGrid<PointType> downSizeFilterSurf;

    V3D euler_cur;

    LidarMeasureGroup LidarMeasures;
    StatesGroup _state;
    StatesGroup state_propagat;

    nav_msgs::Path path;
    nav_msgs::Odometry odomAftMapped;
    geometry_msgs::Quaternion geoQuat;
    geometry_msgs::PoseStamped msg_body_pose;

    PreprocessPtr p_pre;
    ImuProcessPtr p_imu;
    VoxelMapManagerPtr voxelmap_manager;
    VIOManagerPtr vio_manager;

    ros::Publisher plane_pub;
    ros::Publisher voxel_pub;
    ros::Subscriber sub_pcl;
    ros::Subscriber sub_imu;
    std::vector<ros::Subscriber> sub_img_list;
    std::vector<image_transport::Subscriber> it_sub_img_list;  // Image transport subscribers for each camera
    std::vector<ros::Subscriber> sub_compressed_img_list;
    void compressed_img_cbk(const sensor_msgs::CompressedImageConstPtr &msg_in, int cam_id);

    ros::Publisher pubLaserCloudFullRes;
    ros::Publisher pubNormal;
    ros::Publisher pubSubVisualMap;
    ros::Publisher pubLaserCloudEffect;
    ros::Publisher pubLaserCloudMap;
    ros::Publisher pubOdomAftMapped;
    ros::Publisher pubPath;
    ros::Publisher pubLaserCloudDyn;
    ros::Publisher pubLaserCloudDynRmed;
    ros::Publisher pubLaserCloudDynDbg;
    image_transport::Publisher pubImage;
    ros::Publisher mavros_pose_publisher;
    ros::Timer imu_prop_timer;

    int frame_num = 0;
    double aver_time_consu = 0;
    bool colmap_output_en = false;

// Method to get a historical point cloud by timestamp
    PointCloudXYZI::Ptr getHistoricalPointCloud(double timestamp);
    void publish_cloud_body(const ros::Publisher &pubLaserCloudBody,
                            const PointCloudXYZI::Ptr &lidar_cloud,
                            const ros::Time &stamp);
    ros::Publisher pubLaserCloudBody;
    bool pub_body_cloud_en = false;

private:
    void finalizePointCloudFile();
};

#endif