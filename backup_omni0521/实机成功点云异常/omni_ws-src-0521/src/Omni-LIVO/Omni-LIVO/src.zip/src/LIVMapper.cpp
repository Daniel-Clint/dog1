/**
 * @file LIVMapper.cpp
 * @brief LiDAR-Inertial-Visual Mapper implementation for Omni-LIVO
 *
 * @copyright Copyright (c) 2026 Hangzhou Institute for Advanced Study,
 *            University of Chinese Academy of Sciences
 *
 * @par Project: Omni-LIVO
 * Omni-LIVO: Robust RGB-Colored Multi-Camera Visual-Inertial-LiDAR Odometry
 * via Photometric Migration and ESIKF Fusion
 *
 * This work is based on FAST-LIVO2:
 * C. Zheng, W. Xu, Q. Guo, and F. Zhang, "FAST-LIVO2: Fast, direct LiDAR-inertial-visual
 * odometry," IEEE Trans. Robot., vol. 40, pp. 1529-1546, 2024.
 *
 * @author Yinong Cao (cyn_688@163.com), Chenyang Zhang, Xin He*, Yuwei Chen, Chengyu Pu,
 *         Bingtao Wang, Kaile Wu, Shouzheng Zhu, Fei Han, Shijie Liu, Chunlai Li, Jianyu Wang
 * @author *Corresponding author: Xin He (xinhe@ucas.ac.cn)
 *
 * @par Repository
 * https://github.com/elon876/Omni-LIVO
 *
 * @par Citation
 * If you use this code in your research, please cite our paper:
 * Y. Cao et al., "Omni-LIVO: Robust RGB-Colored Multi-Camera Visual-Inertial-LiDAR
 * Odometry via Photometric Migration and ESIKF Fusion," IEEE Robotics and Automation
 * Letters, 2026.
 */

#include "LIVMapper.h"

LIVMapper::LIVMapper(ros::NodeHandle &nh)
        : extT(0, 0, 0),
          extR(M3D::Identity()) {
    extrinT.assign(3, 0.0);
    extrinR.assign(9, 0.0);
    camera_extrin_Ts.clear();
    camera_extrin_Rs.clear();


    p_pre.reset(new Preprocess());
    p_imu.reset(new ImuProcess());

    readParameters(nh);
    VoxelMapConfig voxel_config;
    loadVoxelConfig(nh, voxel_config);

    visual_sub_map.reset(new PointCloudXYZI());
    feats_undistort.reset(new PointCloudXYZI());
    feats_down_body.reset(new PointCloudXYZI());
    feats_down_world.reset(new PointCloudXYZI());
    pcl_w_wait_pub.reset(new PointCloudXYZI());
    pcl_wait_pub.reset(new PointCloudXYZI());
    pcl_wait_save.reset(new PointCloudXYZRGB());
    voxelmap_manager.reset(new VoxelMapManager(voxel_config, voxel_map));
    vio_manager.reset(new VIOManager());
    root_dir = ROOT_DIR;
    initializeFiles();
    initializeComponents();
    path.header.stamp = ros::Time::now();
    path.header.frame_id = "camera_init";

    if (num_of_cameras <= 0) {
        ROS_ERROR("Invalid number of cameras: %d", num_of_cameras);
        return;
    }
    img_buffers.resize(num_of_cameras);
    img_time_buffers.resize(num_of_cameras);
    last_timestamp_imgs.resize(num_of_cameras, -1.0);
}

LIVMapper::~LIVMapper() {
    // 清理所有动态分配的资源
    if (vio_manager) {
        vio_manager->cleanupOldVisualPoints();
        vio_manager->cleanupOldFrames();
    }
    
    // 清空所有缓冲区
    lid_raw_data_buffer.clear();
    lid_header_time_buffer.clear();
    imu_buffer.clear();
    
    for (auto& img_buffer : img_buffers) {
        img_buffer.clear();
    }
    for (auto& img_time_buffer : img_time_buffers) {
        img_time_buffer.clear();
    }
    
    // 重置智能指针
    visual_sub_map.reset();
    feats_undistort.reset();
    feats_down_body.reset();
    feats_down_world.reset();
    pcl_w_wait_pub.reset();
    pcl_wait_pub.reset();
    pcl_wait_save.reset();
    
    // 关闭输出流
    if (fout_pre.is_open()) fout_pre.close();
    if (fout_out.is_open()) fout_out.close();
    if (fout_pcd_pos.is_open()) fout_pcd_pos.close();
    if (fout_points.is_open()) fout_points.close();
}

void LIVMapper::readParameters(ros::NodeHandle &nh) {
    nh.param<string>("common/lid_topic", lid_topic, "/livox/lidar");
    nh.param<string>("common/imu_topic", imu_topic, "/livox/imu");
    nh.param<bool>("common/ros_driver_bug_fix", ros_driver_fix_en, false);
    nh.param<int>("common/img_en", img_en, 1);
    nh.param<int>("common/lidar_en", lidar_en, 1);
    nh.param<bool>("vio/normal_en", normal_en, true);
    nh.param<bool>("vio/inverse_composition_en", inverse_composition_en, false);
    nh.param<int>("vio/max_iterations", max_iterations, 5);
    nh.param<double>("vio/img_point_cov", IMG_POINT_COV, 100);
    nh.param<bool>("vio/exposure_estimate_en", exposure_estimate_en, true);
    nh.param<double>("vio/inv_expo_cov", inv_expo_cov, 0.2);
    nh.param<int>("vio/grid_size", grid_size, 5);
    nh.param<int>("vio/grid_n_height", grid_n_height, 17);
    nh.param<int>("vio/patch_pyrimid_level", patch_pyrimid_level, 3);
    nh.param<int>("vio/patch_size", patch_size, 8);
    nh.param<double>("vio/outlier_threshold", outlier_threshold, 1000);
    nh.param<double>("time_offset/exposure_time_init", exposure_time_init, 0.0);
    nh.param<double>("time_offset/img_time_offset", img_time_offset, 0.0);
    nh.param<double>("time_offset/imu_time_offset", imu_time_offset, 0.0);
    nh.param<bool>("uav/imu_rate_odom", imu_prop_enable, false);
    nh.param<bool>("uav/gravity_align_en", gravity_align_en, false);
    nh.param<string>("evo/seq_name", seq_name, "01");
    nh.param<bool>("evo/pose_output_en", pose_output_en, false);
    nh.param<double>("imu/gyr_cov", gyr_cov, 1.0);
    nh.param<double>("imu/acc_cov", acc_cov, 1.0);
    nh.param<int>("imu/imu_int_frame", imu_int_frame, 3);
    nh.param<bool>("imu/imu_en", imu_en, false);
    nh.param<bool>("imu/gravity_est_en", gravity_est_en, true);
    nh.param<bool>("imu/ba_bg_est_en", ba_bg_est_en, true);
    nh.param<double>("preprocess/blind", p_pre->blind, 0.01);
    nh.param<double>("preprocess/filter_size_surf", filter_size_surf_min, 0.5);
    nh.param<int>("preprocess/lidar_type", p_pre->lidar_type, AVIA);
    nh.param<int>("preprocess/scan_line", p_pre->N_SCANS, 6);
    nh.param<int>("preprocess/point_filter_num", p_pre->point_filter_num, 3);
    nh.param<bool>("preprocess/feature_extract_enabled", p_pre->feature_enabled, false);
    nh.param<int>("pcd_save/interval", pcd_save_interval, -1);
    nh.param<bool>("pcd_save/pcd_save_en", pcd_save_en, false);
    nh.param<bool>("pcd_save/colmap_output_en", colmap_output_en, false);
    nh.param<double>("pcd_save/filter_size_pcd", filter_size_pcd, 0.5);
    nh.param<vector<double>>("extrin_calib/extrinsic_T", extrinT, vector<double>());
    nh.param<vector<double>>("extrin_calib/extrinsic_R", extrinR, vector<double>());
    nh.param<double>("debug/plot_time", plot_time, -10);
    nh.param<int>("debug/frame_cnt", frame_cnt, 6);
    nh.param<double>("publish/blind_rgb_points", blind_rgb_points, 0.01);
    nh.param<int>("publish/pub_scan_num", pub_scan_num, 1);
    nh.param<bool>("publish/pub_effect_point_en", pub_effect_point_en, false);
    nh.param<bool>("publish/pub_body_cloud_en", pub_body_cloud_en, false);
    nh.param<bool>("publish/dense_map_en", dense_map_en, false);

    nh.param<bool>("vio/enable_cross_camera_tracking", enable_cross_camera_tracking, false);
    nh.param<bool>("vio/enable_dynamic_covariance", vio_dynamic_cov_enabled_, false);
    nh.param<int>("vio/dynamic_cov_warmup_frames", vio_dynamic_cov_warmup_frames, 200);
    nh.param<double>("vio/warmup_cov_scale", vio_warmup_cov_scale, 500.0);
    nh.param<double>("vio/min_cov_scale", vio_min_cov_scale, 10.0);
    nh.param<double>("vio/max_cov_scale", vio_max_cov_scale, 2000.0);
    nh.param<double>("vio/dynamic_cov_error_max", vio_dynamic_cov_error_max, 50.0);
    nh.param<int>("vio/max_total_points", max_total_points, 300);

    p_pre->blind_sqr = p_pre->blind * p_pre->blind;

    XmlRpc::XmlRpcValue extrinCams;
    if (nh.getParam("extrin_calib/cameras", extrinCams)) {
        if (extrinCams.getType() == XmlRpc::XmlRpcValue::TypeArray) {
            num_of_cameras = extrinCams.size();
            camera_extrin_Rs.clear();
            camera_extrin_Ts.clear();
            camera_img_topics.clear();
            ROS_INFO("Found %d camera(s) in extrin_calib/cameras.", num_of_cameras);
            for (int i = 0; i < extrinCams.size(); i++) {
                if (extrinCams[i].getType() == XmlRpc::XmlRpcValue::TypeStruct) {
                    std::string cam_topic;
                    if (extrinCams[i].hasMember("img_topic")) {
                        cam_topic = static_cast<std::string>(extrinCams[i]["img_topic"]);
                    }
                    camera_img_topics.push_back(cam_topic);

                    std::vector<double> Rcl_vec;
                    if (extrinCams[i].hasMember("Rcl")) {
                        XmlRpc::XmlRpcValue Rcl_param = extrinCams[i]["Rcl"];
                        if (Rcl_param.getType() == XmlRpc::XmlRpcValue::TypeArray) {
                            for (int j = 0; j < Rcl_param.size(); j++) {
                                double val = 0.0;
                                if (Rcl_param[j].getType() == XmlRpc::XmlRpcValue::TypeDouble)
                                    val = static_cast<double>(Rcl_param[j]);
                                else if (Rcl_param[j].getType() == XmlRpc::XmlRpcValue::TypeInt)
                                    val = static_cast<int>(Rcl_param[j]);
                                Rcl_vec.push_back(val);
                            }
                        }
                    } else {
                        ROS_WARN("Camera %d: Missing Rcl parameter, using identity.", i);
                        Rcl_vec = {1, 0, 0, 0, 1, 0, 0, 0, 1};
                    }
                    camera_extrin_Rs.push_back(Rcl_vec);
                    ROS_INFO("Camera %d: Loaded Rcl: [%f, %f, %f, %f, %f, %f, %f, %f, %f]", i,
                             Rcl_vec[0], Rcl_vec[1], Rcl_vec[2], Rcl_vec[3], Rcl_vec[4], Rcl_vec[5],
                             Rcl_vec[6], Rcl_vec[7], Rcl_vec[8]);

                    std::vector<double> Pcl_vec;
                    if (extrinCams[i].hasMember("Pcl")) {
                        XmlRpc::XmlRpcValue Pcl_param = extrinCams[i]["Pcl"];
                        if (Pcl_param.getType() == XmlRpc::XmlRpcValue::TypeArray) {
                            for (int j = 0; j < Pcl_param.size(); j++) {
                                double val = 0.0;
                                if (Pcl_param[j].getType() == XmlRpc::XmlRpcValue::TypeDouble)
                                    val = static_cast<double>(Pcl_param[j]);
                                else if (Pcl_param[j].getType() == XmlRpc::XmlRpcValue::TypeInt)
                                    val = static_cast<int>(Pcl_param[j]);
                                Pcl_vec.push_back(val);
                            }
                        }
                    } else {
                        ROS_WARN("Camera %d: Missing Pcl parameter, using zeros.", i);
                        Pcl_vec = {0, 0, 0};
                    }
                    camera_extrin_Ts.push_back(Pcl_vec);
                    ROS_INFO("Camera %d: Loaded Pcl: [%f, %f, %f]", i, Pcl_vec[0], Pcl_vec[1], Pcl_vec[2]);
                }
            }
        } else {
            ROS_WARN("extrin_calib/cameras is not an array; using single-camera parameters if available.");
        }
    } else {
        ROS_WARN("No multi-camera extrinsics found under extrin_calib/cameras; falling back to single-camera parameters.");
    }
}

bool loadMultipleCameras(int cams_num, const std::string& ns, std::vector<vk::AbstractCamera*>& cam_list)
{

    bool all_ok = true;
    for (int i = 0; i < cams_num; i++)
    {
        std::string cam_ns = ns + "/cam_" + std::to_string(i);
        vk::AbstractCamera* cam = nullptr;
        if (!vk::camera_loader::loadFromRosNs(cam_ns, cam))
        {
            ROS_ERROR("Failed to load camera at namespace: %s", cam_ns.c_str());
            all_ok = false;
        }
        else
        {
            cam_list.push_back(cam);
            ROS_INFO("Loaded camera %d from namespace: %s", i, cam_ns.c_str());
        }
    }
    return all_ok;
}
void LIVMapper::initializeComponents() {
    downSizeFilterSurf.setLeafSize(filter_size_surf_min, filter_size_surf_min, filter_size_surf_min);
    extT << VEC_FROM_ARRAY(extrinT);
    extR << MAT_FROM_ARRAY(extrinR);

    voxelmap_manager->extT_ << VEC_FROM_ARRAY(extrinT);
    voxelmap_manager->extR_ << MAT_FROM_ARRAY(extrinR);

    if (!loadMultipleCameras(num_of_cameras,"laserMapping", vio_manager->cams))
        throw std::runtime_error("Failed to load camera models from 'laserMapping' namespace.");
    else
        ROS_INFO("Loaded %zu camera(s) successfully.", vio_manager->cams.size());

    vio_manager->grid_size = grid_size;
    vio_manager->patch_size = patch_size;
    vio_manager->outlier_threshold = outlier_threshold;
    vio_manager->setImuToLidarExtrinsic(extT, extR);
    vio_manager->setLidarToCameraExtrinsic(camera_extrin_Rs, camera_extrin_Ts);
    vio_manager->state = &_state;
    vio_manager->state_propagat = &state_propagat;
    vio_manager->max_iterations = max_iterations;
    vio_manager->img_point_cov = IMG_POINT_COV;
    vio_manager->normal_en = normal_en;
    vio_manager->inverse_composition_en = inverse_composition_en;
    vio_manager->grid_n_width = grid_n_width;
    vio_manager->grid_n_height = grid_n_height;
    vio_manager->patch_pyrimid_level = patch_pyrimid_level;
    vio_manager->exposure_estimate_en = exposure_estimate_en;
    vio_manager->colmap_output_en = colmap_output_en;

    vio_manager->enable_cross_camera_tracking = enable_cross_camera_tracking;
    vio_manager->enable_dynamic_covariance_ = vio_dynamic_cov_enabled_;
    vio_manager->dynamic_cov_warmup_frames = vio_dynamic_cov_warmup_frames;
    vio_manager->warmup_cov_scale = vio_warmup_cov_scale;
    vio_manager->min_cov_scale = vio_min_cov_scale;
    vio_manager->max_cov_scale = vio_max_cov_scale;
    vio_manager->dynamic_cov_error_max = vio_dynamic_cov_error_max;
    vio_manager->max_total_points = max_total_points;

    vio_manager->initializeVIO();

    p_imu->set_extrinsic(extT, extR);
    p_imu->set_gyr_cov_scale(V3D(gyr_cov, gyr_cov, gyr_cov));
    p_imu->set_acc_cov_scale(V3D(acc_cov, acc_cov, acc_cov));
    p_imu->set_inv_expo_cov(inv_expo_cov);
    p_imu->set_gyr_bias_cov(V3D(0.0001, 0.0001, 0.0001));
    p_imu->set_acc_bias_cov(V3D(0.0001, 0.0001, 0.0001));
    p_imu->set_imu_init_frame_num(imu_int_frame);

    if (!imu_en) p_imu->disable_imu();
    if (!gravity_est_en) p_imu->disable_gravity_est();
    if (!ba_bg_est_en) p_imu->disable_bias_est();
    if (!exposure_estimate_en) p_imu->disable_exposure_est();

    slam_mode_ = (img_en && lidar_en) ? LIVO : imu_en ? ONLY_LIO : ONLY_LO;
}

void LIVMapper::initializeFiles() {
    if (pcd_save_en && colmap_output_en) {
        const std::string folderPath = std::string(ROOT_DIR) + "/scripts/colmap_output.sh";

        std::string chmodCommand = "chmod +x " + folderPath;

        int chmodRet = system(chmodCommand.c_str());
        if (chmodRet != 0) {
            std::cerr << "Failed to set execute permissions for the script." << std::endl;
            return;
        }

        int executionRet = system(folderPath.c_str());
        if (executionRet != 0) {
            std::cerr << "Failed to execute the script." << std::endl;
            return;
        }
    }
    if (colmap_output_en) fout_points.open(std::string(ROOT_DIR) + "Log/Colmap/sparse/0/points3D.txt", std::ios::out);
    if (pcd_save_interval > 0) fout_pcd_pos.open(std::string(ROOT_DIR) + "Log/PCD/scans_pos.json", std::ios::out);
    fout_pre.open(DEBUG_FILE_DIR("mat_pre.txt"), std::ios::out);
    fout_out.open(DEBUG_FILE_DIR("mat_out.txt"), std::ios::out);
}

void LIVMapper::initializeSubscribersAndPublishers(ros::NodeHandle &nh, image_transport::ImageTransport &it) {
    sub_pcl = p_pre->lidar_type == AVIA ?
              nh.subscribe(lid_topic, 200000, &LIVMapper::livox_pcl_cbk, this) :
              nh.subscribe(lid_topic, 200000, &LIVMapper::standard_pcl_cbk, this);

    sub_imu = nh.subscribe(imu_topic, 200000, &LIVMapper::imu_cbk, this);

    sub_img_list.clear();
    if (!camera_img_topics.empty()) {
        for (int i = 0; i < camera_img_topics.size(); i++) {
            auto img_cb = [i, this](const sensor_msgs::ImageConstPtr& msg) {
                img_cbk(msg, i);
            };

            ros::Subscriber sub = nh.subscribe<sensor_msgs::Image>(
                    camera_img_topics[i],
                    200000,
                    std::bind(img_cb, std::placeholders::_1)
            );

            sub_img_list.push_back(sub);
            ROS_INFO("Subscribed to image topic: %s", camera_img_topics[i].c_str());
        }
    } else {
        ROS_WARN("No multi-camera image topics specified. Please check your configuration.");
    }

    pubLaserCloudFullRes = nh.advertise<sensor_msgs::PointCloud2>("/cloud_registered", 100);
    pubLaserCloudBody = nh.advertise<sensor_msgs::PointCloud2>("/body_cloud", 100);
    pubNormal = nh.advertise<visualization_msgs::MarkerArray>("visualization_marker", 100);
    pubSubVisualMap = nh.advertise<sensor_msgs::PointCloud2>("/cloud_visual_sub_map_before", 100);
    pubLaserCloudEffect = nh.advertise<sensor_msgs::PointCloud2>("/cloud_effected", 100);
    pubLaserCloudMap = nh.advertise<sensor_msgs::PointCloud2>("/Laser_map", 100);
    pubOdomAftMapped = nh.advertise<nav_msgs::Odometry>("/aft_mapped_to_init", 10);
    pubPath = nh.advertise<nav_msgs::Path>("/path", 10);
    plane_pub = nh.advertise<visualization_msgs::Marker>("/planner_normal", 1);
    voxel_pub = nh.advertise<visualization_msgs::MarkerArray>("/voxels", 1);
    pubLaserCloudDyn = nh.advertise<sensor_msgs::PointCloud2>("/dyn_obj", 100);
    pubLaserCloudDynRmed = nh.advertise<sensor_msgs::PointCloud2>("/dyn_obj_removed", 100);
    pubLaserCloudDynDbg = nh.advertise<sensor_msgs::PointCloud2>("/dyn_obj_dbg_hist", 100);
    mavros_pose_publisher = nh.advertise<geometry_msgs::PoseStamped>("/mavros/vision_pose/pose", 10);

    pubImage = it.advertise("/rgb_img", 1);

    pubImuPropOdom = nh.advertise<nav_msgs::Odometry>("/LIVO2/imu_propagate", 10000);
    imu_prop_timer = nh.createTimer(ros::Duration(0.004), &LIVMapper::imu_prop_callback, this);
}


void LIVMapper::handleFirstFrame() {
    if (!is_first_frame) {
        _first_lidar_time = LidarMeasures.last_lio_update_time;
        p_imu->first_lidar_time = _first_lidar_time; // Only for IMU data log
        is_first_frame = true;
        cout << "FIRST LIDAR FRAME!" << endl;
    }
}

void LIVMapper::gravityAlignment() {
    if (!p_imu->imu_need_init && !gravity_align_finished) {
        std::cout << "Gravity Alignment Starts" << std::endl;
        V3D ez(0, 0, -1), gz(_state.gravity);
        Quaterniond G_q_I0 = Quaterniond::FromTwoVectors(gz, ez);
        M3D G_R_I0 = G_q_I0.toRotationMatrix();

        _state.pos_end = G_R_I0 * _state.pos_end;
        _state.rot_end = G_R_I0 * _state.rot_end;
        _state.vel_end = G_R_I0 * _state.vel_end;
        _state.gravity = G_R_I0 * _state.gravity;
        gravity_align_finished = true;
        std::cout << "Gravity Alignment Finished" << std::endl;
    }
}

void LIVMapper::processImu() {
    // double t0 = omp_get_wtime();

    p_imu->Process2(LidarMeasures, _state, feats_undistort);

    if (gravity_align_en) gravityAlignment();

    state_propagat = _state;
    voxelmap_manager->state_ = _state;
    voxelmap_manager->feats_undistort_ = feats_undistort;

    // double t_prop = omp_get_wtime();

    // std::cout << "[ Mapping ] feats_undistort: " << feats_undistort->size() << std::endl;
    // std::cout << "[ Mapping ] predict cov: " << _state.cov.diagonal().transpose() << std::endl;
    // std::cout << "[ Mapping ] predict sta: " << state_propagat.pos_end.transpose() << state_propagat.vel_end.transpose() << std::endl;
}

void LIVMapper::stateEstimationAndMapping() {
    switch (LidarMeasures.lio_vio_flg) {
        case VIO:
            handleVIO();
            break;
        case LIO:
            handleLIO();
            break;
    }
}

void LIVMapper::handleVIO() {
    if (pcl_w_wait_pub->empty() || (pcl_w_wait_pub == nullptr)) {
        std::cout << "[ VIO ] No point!!!" << std::endl;
        return;
    }

    std::cout << "[ VIO ] Raw feature num: " << pcl_w_wait_pub->points.size() << std::endl;

    if (fabs((LidarMeasures.last_lio_update_time - _first_lidar_time) - plot_time) < (frame_cnt / 2 * 0.1)) {
        vio_manager->plot_flag = true;
    } else {
        vio_manager->plot_flag = false;
    }

    std::vector<cv::Mat> imgs = LidarMeasures.measures.back().imgs;
    if (imgs.empty()) {
        ROS_WARN("[ VIO ] No images available in the measurement group; skipping VIO update.");
        return;
    }
    ROS_INFO("[ VIO ] Processing frame with %zu image(s).", imgs.size());

    vio_manager->processFrame(imgs, _pv_list, voxelmap_manager->voxel_map_,
                              LidarMeasures.last_lio_update_time - _first_lidar_time);

    if (imu_prop_enable) {
        ekf_finish_once = true;
        latest_ekf_state = _state;
        latest_ekf_time = LidarMeasures.last_lio_update_time;
        state_update_flg = true;
    }

    publish_frame_world(pubLaserCloudFullRes, vio_manager);
    publish_img_rgb(pubImage, vio_manager);

    if (pub_body_cloud_en && feats_undistort && !feats_undistort->empty()) {
        publish_cloud_body(pubLaserCloudBody, feats_undistort,
                           ros::Time().fromSec(LidarMeasures.last_lio_update_time));
    }
}

void LIVMapper::handleLIO() {
    euler_cur = RotMtoEuler(_state.rot_end);

    if (feats_undistort->empty() || (feats_undistort == nullptr)) {
        std::cout << "[ LIO ]: No point!!!" << std::endl;
        return;
    }

    double t0 = omp_get_wtime();

    downSizeFilterSurf.setInputCloud(feats_undistort);
    downSizeFilterSurf.filter(*feats_down_body);

    double t_down = omp_get_wtime();

    feats_down_size = feats_down_body->points.size();
    voxelmap_manager->feats_down_body_ = feats_down_body;
    transformLidar(_state.rot_end, _state.pos_end, feats_down_body, feats_down_world);
    voxelmap_manager->feats_down_world_ = feats_down_world;
    voxelmap_manager->feats_down_size_ = feats_down_size;

    if (!lidar_map_inited) {
        lidar_map_inited = true;
        voxelmap_manager->BuildVoxelMap();
    }

    double t1 = omp_get_wtime();

    voxelmap_manager->StateEstimation(state_propagat);
    _state = voxelmap_manager->state_;
    _pv_list = voxelmap_manager->pv_list_;

    double t2 = omp_get_wtime();

    if (imu_prop_enable) {
        ekf_finish_once = true;
        latest_ekf_state = _state;
        latest_ekf_time = LidarMeasures.last_lio_update_time;
        state_update_flg = true;
    }

    if (pose_output_en) {
        static bool pos_opend = false;
        static int ocount = 0;
        std::ofstream outFile, evoFile;
        if (!pos_opend) {
            evoFile.open(std::string(ROOT_DIR) + "Log/result/" + seq_name + ".txt", std::ios::out);
            pos_opend = true;
            if (!evoFile.is_open()) ROS_ERROR("open fail\n");
        } else {
            evoFile.open(std::string(ROOT_DIR) + "Log/result/" + seq_name + ".txt", std::ios::app);
            if (!evoFile.is_open()) ROS_ERROR("open fail\n");
        }
        Eigen::Matrix4d outT;
        Eigen::Quaterniond q(_state.rot_end);
        evoFile << std::fixed;
        evoFile << LidarMeasures.last_lio_update_time << " " << _state.pos_end[0] << " " << _state.pos_end[1] << " "
                << _state.pos_end[2] << " "
                << q.x() << " " << q.y() << " " << q.z() << " " << q.w() << std::endl;
    }

    euler_cur = RotMtoEuler(_state.rot_end);
    geoQuat = tf::createQuaternionMsgFromRollPitchYaw(euler_cur(0), euler_cur(1), euler_cur(2));
    publish_odometry(pubOdomAftMapped);

    double t3 = omp_get_wtime();

    PointCloudXYZI::Ptr world_lidar(new PointCloudXYZI());
    transformLidar(_state.rot_end, _state.pos_end, feats_down_body, world_lidar);
    for (size_t i = 0; i < world_lidar->points.size(); i++) {
        voxelmap_manager->pv_list_[i].point_w
                << world_lidar->points[i].x, world_lidar->points[i].y, world_lidar->points[i].z;
        M3D point_crossmat = voxelmap_manager->cross_mat_list_[i];
        M3D var = voxelmap_manager->body_cov_list_[i];
        var = (_state.rot_end * extR) * var * (_state.rot_end * extR).transpose() +
              (-point_crossmat) * _state.cov.block<3, 3>(0, 0) * (-point_crossmat).transpose() +
              _state.cov.block<3, 3>(3, 3);
        voxelmap_manager->pv_list_[i].var = var;
    }
    voxelmap_manager->UpdateVoxelMap(voxelmap_manager->pv_list_,LidarMeasures.last_lio_update_time);
    std::cout << "[ LIO ] Update Voxel Map" << std::endl;
    _pv_list = voxelmap_manager->pv_list_;

    double t4 = omp_get_wtime();

    PointCloudXYZI::Ptr laserCloudFullRes(dense_map_en ? feats_undistort : feats_down_body);
    int size = laserCloudFullRes->points.size();
    PointCloudXYZI::Ptr laserCloudWorld(new PointCloudXYZI(size, 1));

    for (int i = 0; i < size; i++) {
        RGBpointBodyToWorld(&laserCloudFullRes->points[i], &laserCloudWorld->points[i]);
    }
    *pcl_w_wait_pub = *laserCloudWorld;

    if (!img_en) publish_frame_world(pubLaserCloudFullRes, vio_manager);
    if (pub_body_cloud_en) {
        publish_cloud_body(pubLaserCloudBody, laserCloudFullRes,
                           ros::Time().fromSec(LidarMeasures.last_lio_update_time));
    }
    if (pub_effect_point_en) publish_effect_world(pubLaserCloudEffect, voxelmap_manager->ptpl_list_);
    publish_path(pubPath);
    publish_mavros(mavros_pose_publisher);

    frame_num++;
    aver_time_consu = aver_time_consu * (frame_num - 1) / frame_num + (t4 - t0) / frame_num;

    // aver_time_icp = aver_time_icp * (frame_num - 1) / frame_num + (t2 - t1) / frame_num;
    // aver_time_map_inre = aver_time_map_inre * (frame_num - 1) / frame_num + (t4 - t3) / frame_num;
    // aver_time_solve = aver_time_solve * (frame_num - 1) / frame_num + (solve_time) / frame_num;
    // aver_time_const_H_time = aver_time_const_H_time * (frame_num - 1) / frame_num + solve_const_H_time / frame_num;
    // printf("[ mapping time ]: per scan: propagation %0.6f downsample: %0.6f match: %0.6f solve: %0.6f  ICP: %0.6f  map incre: %0.6f total: %0.6f \n"
    //         "[ mapping time ]: average: icp: %0.6f construct H: %0.6f, total: %0.6f \n",
    //         t_prop - t0, t1 - t_prop, match_time, solve_time, t3 - t1, t5 - t3, t5 - t0, aver_time_icp, aver_time_const_H_time, aver_time_consu);

    // printf("\033[1;36m[ LIO mapping time ]: current scan: icp: %0.6f secs, map incre: %0.6f secs, total: %0.6f secs.\033[0m\n"
    //         "\033[1;36m[ LIO mapping time ]: average: icp: %0.6f secs, map incre: %0.6f secs, total: %0.6f secs.\033[0m\n",
    //         t2 - t1, t4 - t3, t4 - t0, aver_time_icp, aver_time_map_inre, aver_time_consu);
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;34m|                         LIO Mapping Time                    |\033[0m\n");
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;34m| %-29s | %-27s |\033[0m\n", "Algorithm Stage", "Time (secs)");
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "DownSample", t_down - t0);
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "ICP", t2 - t1);
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "updateVoxelMap", t4 - t3);
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "Current Total Time", t4 - t0);
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "Average Total Time", aver_time_consu);
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");

}

void LIVMapper::savePCD() {
    // 修复：无论 interval 设置如何，在程序退出时都保存缓冲区中剩余的点云
    if (pcd_save_en && (pcl_wait_save->points.size() > 0 || pcl_wait_pub->points.size() > 0)) {
        // 如果启用了分段保存 (interval > 0)，将剩余部分保存为最后一个文件
        if (pcd_save_interval > 0) {
            if (pcl_wait_save->empty()) return; // 如果没有累积的点云，则不保存
            pcd_index++;
            string final_points_dir(string(string(ROOT_DIR) + "Log/PCD/") + to_string(pcd_index) + string("_final.pcd"));
            pcl::PCDWriter pcd_writer;
            pcd_writer.writeBinary(final_points_dir, *pcl_wait_save);
            std::cout << GREEN << "Saved remaining point cloud data to: " << final_points_dir
                      << " with point count: " << pcl_wait_save->points.size() << RESET << std::endl;
            return; // 完成保存，退出函数
        }

        // pcd_save_interval < 0 的逻辑：保存完整地图
        // 首先，处理 pcl_wait_pub 中剩余的未着色点云
        if (!pcl_wait_pub->empty()) {
            PointCloudXYZRGB::Ptr remaining_rgb_cloud(new PointCloudXYZRGB());
            if (img_en) {
                // 尝试用最后一个有效帧的图像为剩余点云着色 (这是一个近似处理)
                // 注意：这部分逻辑比较复杂，一个更简单的处理是直接赋默认颜色
            }
            // 简单处理：将剩余点云赋为默认白色并添加到待保存队列
            for (const auto& p_xyzi : pcl_wait_pub->points) {
                pcl::PointXYZRGB p_xyzrgb;
                p_xyzrgb.x = p_xyzi.x; p_xyzrgb.y = p_xyzi.y; p_xyzrgb.z = p_xyzi.z;
                p_xyzrgb.r = 255; p_xyzrgb.g = 255; p_xyzrgb.b = 255; // Default white color
                remaining_rgb_cloud->push_back(p_xyzrgb);
            }
            *pcl_wait_save += *remaining_rgb_cloud;
        }

        pcl::PointCloud<pcl::PointXYZRGB>::Ptr downsampled_cloud(new pcl::PointCloud<pcl::PointXYZRGB>);
        pcl::VoxelGrid<pcl::PointXYZRGB> voxel_filter;
        voxel_filter.setInputCloud(pcl_wait_save);
        voxel_filter.setLeafSize(filter_size_pcd, filter_size_pcd, filter_size_pcd);
        voxel_filter.filter(*downsampled_cloud);

        std::string raw_points_dir = std::string(ROOT_DIR) + "Log/PCD/all_raw_points.pcd";
        std::string downsampled_points_dir = std::string(ROOT_DIR) + "Log/PCD/all_downsampled_points.pcd";

        pcl::PCDWriter pcd_writer;

        // Save the raw point cloud data
        pcd_writer.writeBinary(raw_points_dir, *pcl_wait_save);
        std::cout << GREEN << "Raw point cloud data saved to: " << raw_points_dir
                  << " with point count: " << pcl_wait_save->points.size() << RESET << std::endl;

        // Save the downsampled point cloud data
        pcd_writer.writeBinary(downsampled_points_dir, *downsampled_cloud);
        std::cout << GREEN << "Downsampled point cloud data saved to: " << downsampled_points_dir
                  << " with point count after filtering: " << downsampled_cloud->points.size() << RESET << std::endl;

        if (colmap_output_en) {
            fout_points << "# 3D point list with one line of data per point\n";
            fout_points << "#  POINT_ID, X, Y, Z, R, G, B, ERROR\n";
            for (size_t i = 0; i < downsampled_cloud->size(); ++i) {
                const auto &point = downsampled_cloud->points[i];
                fout_points << i << " "
                            << std::fixed << std::setprecision(6)
                            << point.x << " " << point.y << " " << point.z << " "
                            << static_cast<int>(point.r) << " "
                            << static_cast<int>(point.g) << " "
                            << static_cast<int>(point.b) << " "
                            << 0 << std::endl;
            }
        }
    }
}

void LIVMapper::run() {
    ros::Rate rate(5000);
    while (ros::ok()) {
        ros::spinOnce();
        if (!sync_packages(LidarMeasures)) {
            rate.sleep();
            continue;
        }
        handleFirstFrame();

        processImu();

        // if (!p_imu->imu_time_init) continue;

        stateEstimationAndMapping();
    }
    savePCD();
}

void LIVMapper::prop_imu_once(StatesGroup &imu_prop_state, const double dt, V3D acc_avr, V3D angvel_avr) {
    double mean_acc_norm = p_imu->IMU_mean_acc_norm;
    acc_avr = acc_avr * G_m_s2 / mean_acc_norm - imu_prop_state.bias_a;
    angvel_avr -= imu_prop_state.bias_g;

    M3D Exp_f = Exp(angvel_avr, dt);
    /* propogation of IMU attitude */
    imu_prop_state.rot_end = imu_prop_state.rot_end * Exp_f;

    /* Specific acceleration (global frame) of IMU */
    V3D acc_imu = imu_prop_state.rot_end * acc_avr +
                  V3D(imu_prop_state.gravity[0], imu_prop_state.gravity[1], imu_prop_state.gravity[2]);

    /* propogation of IMU */
    imu_prop_state.pos_end = imu_prop_state.pos_end + imu_prop_state.vel_end * dt + 0.5 * acc_imu * dt * dt;

    /* velocity of IMU */
    imu_prop_state.vel_end = imu_prop_state.vel_end + acc_imu * dt;
}

void LIVMapper::imu_prop_callback(const ros::TimerEvent &e) {
    if (p_imu->imu_need_init || !new_imu || !ekf_finish_once) { return; }
    mtx_buffer_imu_prop.lock();
    new_imu = false;
    if (imu_prop_enable && !prop_imu_buffer.empty()) {
        static double last_t_from_lidar_end_time = 0;
        if (state_update_flg) {
            imu_propagate = latest_ekf_state;
            // drop all useless imu pkg
            while ((!prop_imu_buffer.empty() && prop_imu_buffer.front().header.stamp.toSec() < latest_ekf_time)) {
                prop_imu_buffer.pop_front();
            }
            last_t_from_lidar_end_time = 0;
            for (int i = 0; i < prop_imu_buffer.size(); i++) {
                double t_from_lidar_end_time = prop_imu_buffer[i].header.stamp.toSec() - latest_ekf_time;
                double dt = t_from_lidar_end_time - last_t_from_lidar_end_time;
                // cout << "prop dt" << dt << ", " << t_from_lidar_end_time << ", " << last_t_from_lidar_end_time << endl;
                V3D acc_imu(prop_imu_buffer[i].linear_acceleration.x, prop_imu_buffer[i].linear_acceleration.y,
                            prop_imu_buffer[i].linear_acceleration.z);
                V3D omg_imu(prop_imu_buffer[i].angular_velocity.x, prop_imu_buffer[i].angular_velocity.y,
                            prop_imu_buffer[i].angular_velocity.z);
                prop_imu_once(imu_propagate, dt, acc_imu, omg_imu);
                last_t_from_lidar_end_time = t_from_lidar_end_time;
            }
            state_update_flg = false;
        } else {
            V3D acc_imu(newest_imu.linear_acceleration.x, newest_imu.linear_acceleration.y,
                        newest_imu.linear_acceleration.z);
            V3D omg_imu(newest_imu.angular_velocity.x, newest_imu.angular_velocity.y, newest_imu.angular_velocity.z);
            double t_from_lidar_end_time = newest_imu.header.stamp.toSec() - latest_ekf_time;
            double dt = t_from_lidar_end_time - last_t_from_lidar_end_time;
            prop_imu_once(imu_propagate, dt, acc_imu, omg_imu);
            last_t_from_lidar_end_time = t_from_lidar_end_time;
        }

        V3D posi, vel_i;
        Eigen::Quaterniond q;
        posi = imu_propagate.pos_end;
        vel_i = imu_propagate.vel_end;
        q = Eigen::Quaterniond(imu_propagate.rot_end);
        imu_prop_odom.header.frame_id = "world";
        imu_prop_odom.header.stamp = newest_imu.header.stamp;
        imu_prop_odom.pose.pose.position.x = posi.x();
        imu_prop_odom.pose.pose.position.y = posi.y();
        imu_prop_odom.pose.pose.position.z = posi.z();
        imu_prop_odom.pose.pose.orientation.w = q.w();
        imu_prop_odom.pose.pose.orientation.x = q.x();
        imu_prop_odom.pose.pose.orientation.y = q.y();
        imu_prop_odom.pose.pose.orientation.z = q.z();
        imu_prop_odom.twist.twist.linear.x = vel_i.x();
        imu_prop_odom.twist.twist.linear.y = vel_i.y();
        imu_prop_odom.twist.twist.linear.z = vel_i.z();
        pubImuPropOdom.publish(imu_prop_odom);
    }
    mtx_buffer_imu_prop.unlock();
}

void
LIVMapper::transformLidar(const Eigen::Matrix3d rot, const Eigen::Vector3d t, const PointCloudXYZI::Ptr &input_cloud,
                          PointCloudXYZI::Ptr &trans_cloud) {
    PointCloudXYZI().swap(*trans_cloud);
    trans_cloud->reserve(input_cloud->size());
    for (size_t i = 0; i < input_cloud->size(); i++) {
        pcl::PointXYZINormal p_c = input_cloud->points[i];
        Eigen::Vector3d p(p_c.x, p_c.y, p_c.z);
        p = (rot * (extR * p + extT) + t);
        PointType pi;
        pi.x = p(0);
        pi.y = p(1);
        pi.z = p(2);
        pi.intensity = p_c.intensity;
        trans_cloud->points.push_back(pi);
    }
}

void LIVMapper::pointBodyToWorld(const PointType &pi, PointType &po) {
    V3D p_body(pi.x, pi.y, pi.z);
    V3D p_global(_state.rot_end * (extR * p_body + extT) + _state.pos_end);
    po.x = p_global(0);
    po.y = p_global(1);
    po.z = p_global(2);
    po.intensity = pi.intensity;
}

template<typename T>
void LIVMapper::pointBodyToWorld(const Matrix<T, 3, 1> &pi, Matrix<T, 3, 1> &po) {
    V3D p_body(pi[0], pi[1], pi[2]);
    V3D p_global(_state.rot_end * (extR * p_body + extT) + _state.pos_end);
    po[0] = p_global(0);
    po[1] = p_global(1);
    po[2] = p_global(2);
}

template<typename T>
Matrix<T, 3, 1> LIVMapper::pointBodyToWorld(const Matrix<T, 3, 1> &pi) {
    V3D p(pi[0], pi[1], pi[2]);
    p = (_state.rot_end * (extR * p + extT) + _state.pos_end);
    Matrix<T, 3, 1> po(p[0], p[1], p[2]);
    return po;
}

void LIVMapper::RGBpointBodyToWorld(PointType const *const pi, PointType *const po) {
    V3D p_body(pi->x, pi->y, pi->z);
    V3D p_global(_state.rot_end * (extR * p_body + extT) + _state.pos_end);
    po->x = p_global(0);
    po->y = p_global(1);
    po->z = p_global(2);
    po->intensity = pi->intensity;
}

void LIVMapper::standard_pcl_cbk(const sensor_msgs::PointCloud2::ConstPtr &msg) {
    if (!lidar_en) return;
    mtx_buffer.lock();
    // cout<<"got feature"<<endl;
    if (msg->header.stamp.toSec() < last_timestamp_lidar) {
        ROS_ERROR("lidar loop back, clear buffer");
        lid_raw_data_buffer.clear();
        lid_header_time_buffer.clear();
    }
    
    // Prevent buffer overflow by limiting buffer size
    const size_t MAX_LIDAR_BUFFER_SIZE = 1000;  // Adjust as needed
    if (lid_raw_data_buffer.size() >= MAX_LIDAR_BUFFER_SIZE) {
        ROS_WARN_THROTTLE(1.0, "LiDAR buffer is full, removing oldest entries to prevent memory leak");
        lid_raw_data_buffer.pop_front();
        lid_header_time_buffer.pop_front();
    }
    
    // ROS_INFO("get point cloud at time: %.6f", msg->header.stamp.toSec());
    PointCloudXYZI::Ptr ptr(new PointCloudXYZI());
    p_pre->process(msg, ptr);
    lid_raw_data_buffer.push_back(ptr);
    lid_header_time_buffer.push_back(msg->header.stamp.toSec());
    last_timestamp_lidar = msg->header.stamp.toSec();

    mtx_buffer.unlock();
    sig_buffer.notify_all();
}

void LIVMapper::livox_pcl_cbk(const livox_ros_driver2::CustomMsg::ConstPtr &msg_in) {
    if (!lidar_en) return;
    mtx_buffer.lock();
    livox_ros_driver2::CustomMsg::Ptr msg(new livox_ros_driver2::CustomMsg(*msg_in));
    // if ((abs(msg->header.stamp.toSec() - last_timestamp_lidar) > 0.2 && last_timestamp_lidar > 0) || sync_jump_flag)
    // {
    //   ROS_WARN("lidar jumps %.3f\n", msg->header.stamp.toSec() - last_timestamp_lidar);
    //   sync_jump_flag = true;
    //   msg->header.stamp = ros::Time().fromSec(last_timestamp_lidar + 0.1);
    // }
    if (abs(last_timestamp_imu - msg->header.stamp.toSec()) > 1.0 && !imu_buffer.empty()) {
        double timediff_imu_wrt_lidar = last_timestamp_imu - msg->header.stamp.toSec();
        printf("\033[95mSelf sync IMU and LiDAR, HARD time lag is %.10lf \n\033[0m", timediff_imu_wrt_lidar - 0.100);
        // imu_time_offset = timediff_imu_wrt_lidar;
    }

    double cur_head_time = msg->header.stamp.toSec();
    ROS_INFO("Get LiDAR, its header time: %.6f", cur_head_time);
    if (cur_head_time < last_timestamp_lidar) {
        ROS_ERROR("lidar loop back, clear buffer");
        lid_raw_data_buffer.clear();
        lid_header_time_buffer.clear();
    }
    
    // Prevent buffer overflow by limiting buffer size
    const size_t MAX_LIDAR_BUFFER_SIZE = 1000;  // Adjust as needed
    if (lid_raw_data_buffer.size() >= MAX_LIDAR_BUFFER_SIZE) {
        ROS_WARN_THROTTLE(1.0, "LiDAR buffer is full, removing oldest entries to prevent memory leak");
        lid_raw_data_buffer.pop_front();
        lid_header_time_buffer.pop_front();
    }
    
    // ROS_INFO("get point cloud at time: %.6f", msg->header.stamp.toSec());
    PointCloudXYZI::Ptr ptr(new PointCloudXYZI());
    p_pre->process(msg, ptr);
    lid_raw_data_buffer.push_back(ptr);
    lid_header_time_buffer.push_back(cur_head_time);
    last_timestamp_lidar = cur_head_time;

    mtx_buffer.unlock();
    sig_buffer.notify_all();
}

void LIVMapper::imu_cbk(const sensor_msgs::Imu::ConstPtr &msg_in) {
    if (!imu_en) return;

    if (last_timestamp_lidar < 0.0) return;
    // ROS_INFO("get imu at time: %.6f", msg_in->header.stamp.toSec());
    sensor_msgs::Imu::Ptr msg(new sensor_msgs::Imu(*msg_in));
    msg->header.stamp = ros::Time().fromSec(msg->header.stamp.toSec() - imu_time_offset);
    double timestamp = msg->header.stamp.toSec();

    if (fabs(last_timestamp_lidar - timestamp) > 0.5 && (!ros_driver_fix_en)) {
        ROS_WARN("IMU and LiDAR not synced! delta time: %lf .\n", last_timestamp_lidar - timestamp);
    }

    if (ros_driver_fix_en) timestamp += std::round(last_timestamp_lidar - timestamp);
    msg->header.stamp = ros::Time().fromSec(timestamp);

    mtx_buffer.lock();

    if (last_timestamp_imu > 0.0 && timestamp < last_timestamp_imu) {
        mtx_buffer.unlock();
        sig_buffer.notify_all();
        ROS_ERROR("imu loop back, offset: %lf \n", last_timestamp_imu - timestamp);
        return;
    }

    if (last_timestamp_imu > 0.0 && timestamp > last_timestamp_imu + 0.2) {

        ROS_WARN("imu time stamp Jumps %0.4lf seconds \n", timestamp - last_timestamp_imu);
        mtx_buffer.unlock();
        sig_buffer.notify_all();
        return;
    }

    last_timestamp_imu = timestamp;

    imu_buffer.push_back(msg);
    // cout<<"got imu: "<<timestamp<<" imu size "<<imu_buffer.size()<<endl;
    mtx_buffer.unlock();
    if (imu_prop_enable) {
        mtx_buffer_imu_prop.lock();
        if (imu_prop_enable && !p_imu->imu_need_init) { prop_imu_buffer.push_back(*msg); }
        newest_imu = *msg;
        new_imu = true;
        mtx_buffer_imu_prop.unlock();
    }
    sig_buffer.notify_all();
}

cv::Mat LIVMapper::getImageFromMsg(const sensor_msgs::ImageConstPtr &img_msg) {
    cv::Mat img;
    img = cv_bridge::toCvCopy(img_msg, "bgr8")->image;
    return img;
}

// static int i = 0;
void LIVMapper::img_cbk(const sensor_msgs::ImageConstPtr &msg_in, int cam_id) {
    ROS_INFO("img_buffers size: %zu", img_buffers.size());

    if (!img_en) return;

    double msg_header_time = msg_in->header.stamp.toSec() + img_time_offset;

    ROS_INFO("Camera %d: Received image with timestamp %.6f", cam_id, msg_header_time);


    if (last_timestamp_lidar < 0) {
        return;
    }

    if (msg_header_time < last_timestamp_imgs[cam_id]) {
        ROS_ERROR("Camera %d: Image timestamp %.6f is earlier than the last image timestamp %.6f. Possible loop-back.", cam_id, msg_header_time, last_timestamp_imgs[cam_id]);
        return;
    }

    mtx_buffer.lock();
    double img_time_correct = msg_header_time;

    cv::Mat img_cur = getImageFromMsg(msg_in);
    if (cam_id < 0 || cam_id >= img_buffers.size()) {
        ROS_ERROR("Invalid cam_id: %d. It should be between 0 and %d .", cam_id, img_buffers.size() - 1);
        mtx_buffer.unlock();
        return;
    }
    img_buffers[cam_id].push_back(img_cur);
    img_time_buffers[cam_id].push_back(img_time_correct);
    last_timestamp_imgs[cam_id] = img_time_correct;
    mtx_buffer.unlock();
    sig_buffer.notify_all();
}

bool LIVMapper::sync_packages(LidarMeasureGroup &meas)
{
    if (lid_raw_data_buffer.empty() && lidar_en)
        return false;

    if (img_en) {
        for (int i = 0; i < num_of_cameras; i++) {
            if (img_buffers[i].empty())
                return false;
        }
    }

    if (imu_buffer.empty() && imu_en)
        return false;

    switch (slam_mode_) {
        case ONLY_LIO:
        {
            if (meas.last_lio_update_time < 0.0) meas.last_lio_update_time = lid_header_time_buffer.front();
            if (!lidar_pushed)
            {
                // If not push the lidar into measurement data buffer
                meas.lidar = lid_raw_data_buffer.front(); // push the first lidar topic
                if (meas.lidar->points.size() <= 1) return false;

                meas.lidar_frame_beg_time = lid_header_time_buffer.front();                                                // generate lidar_frame_beg_time
                meas.lidar_frame_end_time = meas.lidar_frame_beg_time + meas.lidar->points.back().curvature / double(1000); // calc lidar scan end time
                meas.pcl_proc_cur = meas.lidar;
                lidar_pushed = true;                                                                                       // flag
            }

            if (imu_en && last_timestamp_imu < meas.lidar_frame_end_time)
            { // waiting imu message needs to be
                // larger than _lidar_frame_end_time,
                // make sure complete propagate.
                return false;
            }

            struct MeasureGroup m; // standard method to keep imu message.

            m.imu.clear();
            m.lio_time = meas.lidar_frame_end_time;
            mtx_buffer.lock();
            while (!imu_buffer.empty())
            {
                if (imu_buffer.front()->header.stamp.toSec() > meas.lidar_frame_end_time) break;
                m.imu.push_back(imu_buffer.front());
                imu_buffer.pop_front();
            }
            lid_raw_data_buffer.pop_front();
            lid_header_time_buffer.pop_front();
            mtx_buffer.unlock();
            sig_buffer.notify_all();

            meas.lio_vio_flg = LIO; // process lidar topic, so timestamp should be lidar scan end.
            
            // 【内存泄漏修复】限制measures大小，防止无限增长
            while (meas.measures.size() > 5) {
                meas.measures.pop_front();
            }
            meas.measures.push_back(m);
            lidar_pushed = false; // sync one whole lidar scan.
            return true;
        }

        case LIVO:
        {
            EKF_STATE last_lio_vio_flg = meas.lio_vio_flg;
            switch (last_lio_vio_flg) {
                case WAIT:
                case VIO:
                {
                    const double time_tolerance = 0.010; // 放宽容忍度至10ms，适配硬件触发偏差
                    double ref_timestamp = img_time_buffers[0].front();
                    bool timestamps_consistent = true;

                    for (int i = 1; i < num_of_cameras; i++) {
                        double time_diff = std::abs(img_time_buffers[i].front() - ref_timestamp);
                        if (time_diff > time_tolerance) {
                            timestamps_consistent = false;
                            ROS_WARN("Camera timestamps inconsistent: cam0=%.6f, cam%d=%.6f, diff=%.6f ms",
                                     ref_timestamp, i, img_time_buffers[i].front(), time_diff * 1000.0);
                            break;
                        }
                    }

                    if (!timestamps_consistent) {
                        mtx_buffer.lock();

                        int earliest_cam = 0;
                        for (int i = 1; i < num_of_cameras; i++) {
                            if (img_time_buffers[i].front() < img_time_buffers[earliest_cam].front()) {
                                earliest_cam = i;
                            }
                        }

                        img_buffers[earliest_cam].pop_front();
                        img_time_buffers[earliest_cam].pop_front();

                        mtx_buffer.unlock();
                        sig_buffer.notify_all();
                        return false;
                    }

                    if (meas.last_lio_update_time < 0.0)
                        meas.last_lio_update_time = lid_header_time_buffer.front();

                    double img_capture_time = ref_timestamp + exposure_time_init;

                    double lid_newest_time = lid_header_time_buffer.back() +
                                             lid_raw_data_buffer.back()->points.back().curvature / 1000.0;
                    double imu_newest_time = imu_en ? imu_buffer.back()->header.stamp.toSec() : img_capture_time + 1.0;

                    if (img_capture_time < meas.last_lio_update_time + 0.00001) {
                        mtx_buffer.lock();
                        for (int i = 0; i < num_of_cameras; i++) {
                            img_buffers[i].pop_front();
                            img_time_buffers[i].pop_front();
                        }
                        mtx_buffer.unlock();
                        sig_buffer.notify_all();

                        return false;
                    }

                    if (img_capture_time > lid_newest_time || img_capture_time > imu_newest_time) {
                        return false;
                    }

                    MeasureGroup m;
                    m.imu.clear();
                    m.lio_time = img_capture_time;

                    if (imu_en) {
                        mtx_buffer.lock();
                        while (!imu_buffer.empty()) {
                            double imu_time = imu_buffer.front()->header.stamp.toSec();
                            if (imu_time > m.lio_time)
                                break;
                            if (imu_time > meas.last_lio_update_time)
                                m.imu.push_back(imu_buffer.front());
                            imu_buffer.pop_front();
                        }
                        mtx_buffer.unlock();
                    }

                    *(meas.pcl_proc_cur) = *(meas.pcl_proc_next);
                    PointCloudXYZI().swap(*meas.pcl_proc_next);

                    int lid_frame_num = lid_raw_data_buffer.size();
                    int max_size = meas.pcl_proc_cur->size() + 24000 * lid_frame_num;
                    meas.pcl_proc_cur->reserve(max_size);
                    meas.pcl_proc_next->reserve(max_size);

                    while (!lid_raw_data_buffer.empty()) {
                        if (lid_header_time_buffer.front() > img_capture_time)
                            break;

                        auto pcl = lid_raw_data_buffer.front()->points;
                        double frame_header_time = lid_header_time_buffer.front();
                        float max_offs_time_ms = (m.lio_time - frame_header_time) * 1000.0f;

                        for (size_t i = 0; i < pcl.size(); i++) {
                            auto pt = pcl[i];
                            if (pcl[i].curvature < max_offs_time_ms) {
                                pt.curvature += (frame_header_time - meas.last_lio_update_time) * 1000.0f;
                                meas.pcl_proc_cur->points.push_back(pt);
                            }
                            else {
                                pt.curvature += (frame_header_time - m.lio_time) * 1000.0f;
                                meas.pcl_proc_next->points.push_back(pt);
                            }
                        }
                        lid_raw_data_buffer.pop_front();
                        lid_header_time_buffer.pop_front();
                    }

                    m.imgs.resize(num_of_cameras);
                    for (int i = 0; i < num_of_cameras; i++) {
                        m.imgs[i] = img_buffers[i].front();
                    }

                    ROS_INFO("[ LIVO ] Synced LIO: img_time=%.6f, pcl_cur=%zu, pcl_next=%zu",
                             img_capture_time, meas.pcl_proc_cur->size(), meas.pcl_proc_next->size());

                    // 【内存泄漏修复】限制measures大小，防止无限增长
                    while (meas.measures.size() > 10) {
                        meas.measures.pop_front();
                    }
                    meas.measures.push_back(m);
                    meas.lio_vio_flg = LIO;
                    lidar_pushed = false;
                    sig_buffer.notify_all();
                    return true;
                }

                case LIO:
                {
                    const double time_tolerance = 0.010; // 放宽容忍度至10ms，适配硬件触发偏差
                    double ref_timestamp = img_time_buffers[0].front();
                    bool timestamps_consistent = true;

                    for (int i = 1; i < num_of_cameras; i++) {
                        double time_diff = std::abs(img_time_buffers[i].front() - ref_timestamp);
                        if (time_diff > time_tolerance) {
                            timestamps_consistent = false;
                            ROS_WARN("VIO stage: Camera timestamps inconsistent: cam0=%.6f, cam%d=%.6f, diff=%.6f ms",
                                     ref_timestamp, i, img_time_buffers[i].front(), time_diff * 1000.0);
                            break;
                        }
                    }

                    if (!timestamps_consistent) {
                        int earliest_cam = 0;
                        for (int i = 1; i < num_of_cameras; i++) {
                            if (img_time_buffers[i].front() < img_time_buffers[earliest_cam].front()) {
                                earliest_cam = i;
                            }
                        }

                        ROS_WARN("VIO stage: Dropping earliest frame from camera %d (t=%.6f)",
                                 earliest_cam, img_time_buffers[earliest_cam].front());
                        img_buffers[earliest_cam].pop_front();
                        img_time_buffers[earliest_cam].pop_front();

                        sig_buffer.notify_all();
                        return false;
                    }

                    double img_capture_time = ref_timestamp + exposure_time_init;
                    meas.lio_vio_flg = VIO;

                    meas.measures.clear();

                    MeasureGroup m;
                    m.imgs.resize(num_of_cameras);
                    m.vio_time = img_capture_time;
                    m.lio_time = meas.last_lio_update_time;

                    mtx_buffer.lock();
                    for (int i = 0; i < num_of_cameras; i++) {
                        m.imgs[i] = img_buffers[i].front();
                        img_buffers[i].pop_front();
                        img_time_buffers[i].pop_front();
                    }
                    mtx_buffer.unlock();

                    ROS_INFO("[ LIVO ] VIO processing: img_time=%.6f", img_capture_time);

                    meas.measures.push_back(m);
                    lidar_pushed = false;
                    sig_buffer.notify_all();
                    return true;
                }

                default:
                    return false;
            } // end switch(last_lio_vio_flg)
            break;
        }

        default:
        {
            ROS_ERROR("!! WRONG SLAM TYPE !!");
            return false;
        }
    } // end switch(slam_mode_)

    ROS_ERROR("sync failed!");
    return false;
}

void LIVMapper::publish_img_rgb(const image_transport::Publisher &pubImage, VIOManagerPtr vio_manager) {
    //只发布主相机
    cv::Mat img_rgb = vio_manager->panorama_image;

    cv_bridge::CvImage out_msg;
    out_msg.header.stamp = ros::Time::now();
//    out_msg.header.frame_id = "camera_init";
    out_msg.encoding = sensor_msgs::image_encodings::BGR8;
    out_msg.image = img_rgb;
    // ROS_INFO("img_rgb: size = (%d, %d), type = %d, isContinuous = %d",
    //          out_msg.image.cols, out_msg.image.rows, out_msg.image.type(), out_msg.image.isContinuous());
    pubImage.publish(out_msg.toImageMsg());
}

void LIVMapper::publish_frame_world(const ros::Publisher &pubLaserCloudFullRes, VIOManagerPtr vio_manager) {
    if (pcl_w_wait_pub->empty()) return;

    ROS_INFO_THROTTLE(1.0,
                      "[MemDiag][PublishBefore] pcl_w_wait_pub=%zu pcl_wait_pub=%zu pcl_wait_save=%zu pub_scan_num=%d img_en=%d",
                      pcl_w_wait_pub->size(),
                      pcl_wait_pub->size(),
                      pcl_wait_save->size(),
                      pub_scan_num,
                      img_en);

    // 为多相机创建RGB点云
    PointCloudXYZRGB::Ptr laserCloudWorldRGB(new PointCloudXYZRGB());
    PointCloudXYZI::Ptr color_source_cloud = pcl_w_wait_pub;
    bool keep_wait_pub_for_future_batch = false;

    if (img_en) {
        static int pub_num = 1;
        if (pub_scan_num > 1) {
            *pcl_wait_pub += *pcl_w_wait_pub;
            keep_wait_pub_for_future_batch = true;

            if (pub_num >= pub_scan_num) {
                pub_num = 1;
                color_source_cloud = pcl_wait_pub;
                keep_wait_pub_for_future_batch = false;
            } else {
                pub_num++;
            }
        } else {
            pub_num = 1;
        }

        const bool should_generate_rgb =
                (pub_scan_num <= 1) || (!keep_wait_pub_for_future_batch && !color_source_cloud->empty());

        if (should_generate_rgb) {
            const size_t size = color_source_cloud->points.size();
            laserCloudWorldRGB->reserve(size);

            // 遍历所有相机进行图像点云合并
            for (int cam_idx = 0; cam_idx < vio_manager->cams.size(); ++cam_idx) {
                cv::Mat img_rgb = vio_manager->imgs_rgb[cam_idx];

                for (size_t i = 0; i < size; ++i) {
                    PointTypeRGB pointRGB;
                    pointRGB.x = color_source_cloud->points[i].x;
                    pointRGB.y = color_source_cloud->points[i].y;
                    pointRGB.z = color_source_cloud->points[i].z;

                    V3D p_w(color_source_cloud->points[i].x,
                            color_source_cloud->points[i].y,
                            color_source_cloud->points[i].z);
                    V3D pf = vio_manager->new_frame_->w2f(p_w, cam_idx);
                    if (pf[2] < 0) continue;

                    V2D pc = vio_manager->new_frame_->w2c(p_w, cam_idx);
                    if (vio_manager->new_frame_->cams_[cam_idx]->isInFrame(pc.cast<int>(), 3)) {
                        V3F pixel = vio_manager->getInterpolatedPixel(img_rgb, pc);
                        pointRGB.r = pixel[2];
                        pointRGB.g = pixel[1];
                        pointRGB.b = pixel[0];

                        if (pf.norm() > blind_rgb_points) {
                            laserCloudWorldRGB->push_back(pointRGB);
                        }
                    }
                }
            }
        }
    }

    // 发布点云数据
    sensor_msgs::PointCloud2 laserCloudmsg;
    if (img_en && !laserCloudWorldRGB->empty()) {
        pcl::toROSMsg(*laserCloudWorldRGB, laserCloudmsg);
    } else {
        pcl::toROSMsg(*pcl_w_wait_pub, laserCloudmsg);
    }

    laserCloudmsg.header.stamp = ros::Time::now();
    laserCloudmsg.header.frame_id = "camera_init";
    pubLaserCloudFullRes.publish(laserCloudmsg);

    // 保存PCD文件
    if (pcd_save_en) {
        static int scan_wait_num = 0;

        // 【关键修复】仅在 laserCloudWorldRGB 非空时才进行累积，避免对空点云进行操作，防止潜在的PCL库bug
        if (!laserCloudWorldRGB->empty()) {
            *pcl_wait_save += *laserCloudWorldRGB;
        }

        scan_wait_num++;

        if (pcl_wait_save->size() > 0 && pcd_save_interval > 0 && scan_wait_num >= pcd_save_interval) {
            pcd_index++;
            string all_points_dir(string(string(ROOT_DIR) + "Log/PCD/") + to_string(pcd_index) + string(".pcd"));
            pcl::PCDWriter pcd_writer;
            if (pcd_save_en) {
                cout << "current scan saved to /PCD/" << all_points_dir << endl;
                pcd_writer.writeBinary(all_points_dir, *pcl_wait_save); // 保存为PCD文件
                PointCloudXYZRGB().swap(*pcl_wait_save);
                Eigen::Quaterniond q(_state.rot_end);
                fout_pcd_pos << _state.pos_end[0] << " " << _state.pos_end[1] << " " << _state.pos_end[2] << " "
                             << q.w() << " " << q.x() << " " << q.y() << " " << q.z() << " " << endl;
                scan_wait_num = 0;
            }
        }
    }

    // 内存清理优化
    if (!keep_wait_pub_for_future_batch) {
        PointCloudXYZI().swap(*pcl_wait_pub);
    }
    PointCloudXYZRGB().swap(*laserCloudWorldRGB); // 总是清空本次发布的点云
    PointCloudXYZI().swap(*pcl_w_wait_pub); // 总是清空当前帧的原始世界点云
    
    ROS_INFO_THROTTLE(1.0,
                      "[MemDiag][PublishAfter] pcl_w_wait_pub=%zu pcl_wait_pub=%zu pcl_wait_save=%zu rgb_frame_points=%zu keep_wait_pub=%d",
                      pcl_w_wait_pub->size(),
                      pcl_wait_pub->size(),
                      pcl_wait_save->size(),
                      laserCloudWorldRGB->size(),
                      keep_wait_pub_for_future_batch ? 1 : 0);
}

void LIVMapper::publish_visual_sub_map(const ros::Publisher &pubSubVisualMap) {
    PointCloudXYZI::Ptr laserCloudFullRes(visual_sub_map);
    int size = laserCloudFullRes->points.size();
    if (size == 0) return;
    PointCloudXYZI::Ptr sub_pcl_visual_map_pub(new PointCloudXYZI());
    *sub_pcl_visual_map_pub = *laserCloudFullRes;
    if (1) {
        sensor_msgs::PointCloud2 laserCloudmsg;
        pcl::toROSMsg(*sub_pcl_visual_map_pub, laserCloudmsg);
        laserCloudmsg.header.stamp = ros::Time::now();
        laserCloudmsg.header.frame_id = "camera_init";
        pubSubVisualMap.publish(laserCloudmsg);
    }
}

void
LIVMapper::publish_effect_world(const ros::Publisher &pubLaserCloudEffect, const std::vector<PointToPlane> &ptpl_list) {
    int effect_feat_num = ptpl_list.size();
    PointCloudXYZI::Ptr laserCloudWorld(new PointCloudXYZI(effect_feat_num, 1));
    for (int i = 0; i < effect_feat_num; i++) {
        laserCloudWorld->points[i].x = ptpl_list[i].point_w_[0];
        laserCloudWorld->points[i].y = ptpl_list[i].point_w_[1];
        laserCloudWorld->points[i].z = ptpl_list[i].point_w_[2];
    }
    sensor_msgs::PointCloud2 laserCloudFullRes3;
    pcl::toROSMsg(*laserCloudWorld, laserCloudFullRes3);
    laserCloudFullRes3.header.stamp = ros::Time::now();
    laserCloudFullRes3.header.frame_id = "camera_init";
    pubLaserCloudEffect.publish(laserCloudFullRes3);
}

template<typename T>
void LIVMapper::set_posestamp(T &out) {
    out.position.x = _state.pos_end(0);
    out.position.y = _state.pos_end(1);
    out.position.z = _state.pos_end(2);
    out.orientation.x = geoQuat.x;
    out.orientation.y = geoQuat.y;
    out.orientation.z = geoQuat.z;
    out.orientation.w = geoQuat.w;
}

void LIVMapper::publish_cloud_body(const ros::Publisher &pubLaserCloudBody,
                                   const PointCloudXYZI::Ptr &lidar_cloud,
                                   const ros::Time &stamp) {
    if (!pub_body_cloud_en || !lidar_cloud || lidar_cloud->empty()) {
        return;
    }

    PointCloudXYZI::Ptr body_cloud(new PointCloudXYZI());
    body_cloud->reserve(lidar_cloud->size());

    for (const auto &pt : lidar_cloud->points) {
        if (!std::isfinite(pt.x) || !std::isfinite(pt.y) || !std::isfinite(pt.z)) {
            continue;
        }
        const V3D p_lidar(pt.x, pt.y, pt.z);
        const V3D p_body = extR * p_lidar + extT;
        PointType out;
        out.x = static_cast<float>(p_body(0));
        out.y = static_cast<float>(p_body(1));
        out.z = static_cast<float>(p_body(2));
        out.intensity = pt.intensity;
        body_cloud->push_back(out);
    }

    if (body_cloud->empty()) {
        return;
    }

    sensor_msgs::PointCloud2 cloud_msg;
    pcl::toROSMsg(*body_cloud, cloud_msg);
    cloud_msg.header.stamp = stamp.isZero() ? ros::Time::now() : stamp;
    cloud_msg.header.frame_id = "aft_mapped";
    pubLaserCloudBody.publish(cloud_msg);
}

void LIVMapper::publish_odometry(const ros::Publisher &pubOdomAftMapped) {
    odomAftMapped.header.frame_id = "camera_init";
    odomAftMapped.child_frame_id = "aft_mapped";
    odomAftMapped.header.stamp = ros::Time::now(); //.ros::Time()fromSec(last_timestamp_lidar);
    set_posestamp(odomAftMapped.pose.pose);

    static tf::TransformBroadcaster br;
    tf::Transform transform;
    tf::Quaternion q;
    transform.setOrigin(tf::Vector3(_state.pos_end(0), _state.pos_end(1), _state.pos_end(2)));
    q.setW(geoQuat.w);
    q.setX(geoQuat.x);
    q.setY(geoQuat.y);
    q.setZ(geoQuat.z);
    transform.setRotation(q);
    br.sendTransform(tf::StampedTransform(transform, odomAftMapped.header.stamp, "camera_init", "aft_mapped"));
    pubOdomAftMapped.publish(odomAftMapped);
}

void LIVMapper::publish_mavros(const ros::Publisher &mavros_pose_publisher) {
    msg_body_pose.header.stamp = ros::Time::now();
    msg_body_pose.header.frame_id = "camera_init";
    set_posestamp(msg_body_pose.pose);
    mavros_pose_publisher.publish(msg_body_pose);
}

void LIVMapper::publish_path(const ros::Publisher pubPath) {
    set_posestamp(msg_body_pose.pose);
    msg_body_pose.header.stamp = ros::Time::now();
    msg_body_pose.header.frame_id = "camera_init";
    path.poses.push_back(msg_body_pose);
    pubPath.publish(path);
}
